package artista_di_strada;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class data {
	private static final int numeroS = 4;
    private static final int attesa = 5000;
    
    static Semaphore mutex; 
    
	public data() {
		mutex = new Semaphore(numeroS, true);
	}

	public void prova() {
		Thread ta = new Thread(new artista());
		ta.start();

		Random random = new Random();
		int numeroC=1;

		while (true) {
			try {
				Thread.sleep(random.nextInt(2000));
				Thread tc = new Thread(new clienti(numeroC));
				tc.start();
				numeroC++;
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
