package artista_di_strada;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class artista implements Runnable {


	private static final int numeroS = 4; 
	private static final int attesa = 5000; 

	private Semaphore mutex; 
	
	@Override
	public void run() {
		while (true) {
			try {
				Semaphore mutex = new Semaphore(0);
				mutex.acquire(); 
				System.out.println("L'artista sta eseguendo un ritratto...");

				Thread.sleep(new Random().nextInt(5000));

				System.out.println("Il ritratto è pronto. L'artista ha liberato una sedia.");
				mutex.release(); 
			} catch (InterruptedException e) {
				e.printStackTrace();
			}


		}
	}
}
