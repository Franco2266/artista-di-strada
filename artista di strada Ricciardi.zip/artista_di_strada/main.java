package artista_di_strada;
import java.util.Random;
import java.util.concurrent.Semaphore;

public class main {

	public static void main(String[] args) {
		  data a = new data();
	        a.prova();

	}

}
