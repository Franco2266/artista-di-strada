package artista_di_strada;
import java.util.Random;
import java.util.concurrent.Semaphore;

class clienti implements Runnable {
    private int numeroC;
    
    public clienti(int numeroC) {
        this.numeroC = numeroC;
    }
    
    @Override
    public void run() {
        try {
			if (data.mutex.tryAcquire()) {
                System.out.println("Il cliente " + numeroC + " ha trovato una sedia libera e si e' seduto");
                Thread.sleep(new Random().nextInt(10000));
                System.out.println("Il cliente " + numeroC + " ha preso il suo ritratto e lascia libera la sedia");
                data.mutex.release(); 
            } else {
                System.out.println("Il cliente " + numeroC + " ha aspettato troppo e ha deciso di andarsene.");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}